// ============================================================
// helpers.js — Audio, haptic, TTS, translation, and UI utils
// ============================================================
import { state, escHtml } from './state.js';

// Pre-load voices on page load (required for some browsers)
if ('speechSynthesis' in window) {
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
}

// ─── HAPTIC ──────────────────────────────────────────────────
export const haptic = (pattern = 40) => {
  if (navigator.vibrate) navigator.vibrate(pattern);
};

// ─── TOAST ───────────────────────────────────────────────────
export const showToast = (msg, isError = false) => {
  // Remove existing toasts
  document.querySelectorAll('.app-toast').forEach(t => t.remove());

  const toast = document.createElement('div');
  const bg = isError ? 'bg-red-500' : 'bg-green-500';
  const icon = isError ? '⚠️' : '✓';
  toast.className = `app-toast fixed top-5 left-1/2 -translate-x-1/2 ${bg} text-white px-6 py-3 rounded-full shadow-2xl z-[10000] text-sm font-bold flex items-center gap-2 animate-pop border border-white/20 pointer-events-none`;
  toast.textContent = `${icon} ${msg}`;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.transition = 'opacity 0.3s, transform 0.3s';
    toast.style.opacity = '0';
    toast.style.transform = 'translate(-50%, -20px)';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
};

// ─── AUDIO / TTS ─────────────────────────────────────────────
export const playAudio = (textHangul) => {
  if (!textHangul) return;
  haptic(30);
  // Strip any HTML tags (safety)
  const clean = String(textHangul).replace(/<[^>]*>/g, '');
  if (!('speechSynthesis' in window)) {
    showToast("Il tuo browser non supporta la pronuncia.", true);
    return;
  }
  window.speechSynthesis.cancel();
  const utt = new SpeechSynthesisUtterance(clean);
  utt.lang = 'ko-KR';
  utt.rate = 0.85;
  const voices = window.speechSynthesis.getVoices();
  const koVoice = voices.find(v => v.lang.includes('ko') && /Yuna|Somi|Female|Google/i.test(v.name))
    || voices.find(v => v.lang.includes('ko'));
  if (koVoice) utt.voice = koVoice;
  window.speechSynthesis.speak(utt);
};

// ─── RENDERING HELPER: Clickable Korean Word ─────────────────
// Returns safe HTML for a tappable Hangul word (no inline event injection)
export const renderHangul = (text) => {
  const safe = escHtml(text);
  return `<span class="korean-click" data-hangul="${safe}" tabindex="0" role="button" aria-label="Ascolta la pronuncia" title="Tocca per ascoltare">${safe}</span>`;
};

// ─── TRANSLATION ─────────────────────────────────────────────
export const translateToKorean = async (text) => {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=it&tl=ko&dt=t&dt=rm&q=${encodeURIComponent(text)}`;
  const res = await fetch(url);
  const data = await res.json();

  let koText = '';
  let romajiText = '';

  if (data && data[0]) {
    data[0].forEach(item => {
      if (item[0] && typeof item[0] === 'string' && item[0] !== 'null' && !item[0].match(/^[a-zA-Z\s]+$/)) {
        koText += item[0];
      }
      const romajiCandidate = item[2] || item[3];
      if (romajiCandidate && typeof romajiCandidate === 'string' && /^[a-zA-ZāēīōūÄÖÜ\-\s']+$/i.test(romajiCandidate)) {
        romajiText += romajiCandidate;
      }
    });
  }

  return {
    hangul: koText || null,
    romaji: romajiText.trim() || "Audio disponibile sotto"
  };
};

// ─── GLOBAL CLICK HANDLER for korean-click spans ─────────────
// Delegates audio playback via data attribute (no inline onclick)
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-hangul]');
  if (el) {
    e.preventDefault();
    e.stopPropagation();
    playAudio(el.dataset.hangul);
  }
});
document.addEventListener('keydown', (e) => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[data-hangul]')) {
    e.preventDefault();
    playAudio(e.target.dataset.hangul);
  }
});
