// ============================================================
// course.js — Generates the full 45-day course lazily
// ============================================================
import { DETAILED_LESSONS, ADVANCED_TOPICS } from './data.js';

// Cache generated days so we only build each one once
const _cache = {};

/**
 * Returns data for a specific day (1–45), generating it on demand.
 * Days 1–5 come from DETAILED_LESSONS; days 6–45 are procedurally built.
 */
export const getDay = (dayNum) => {
  if (_cache[dayNum]) return _cache[dayNum];

  // Days 1–5: pre-authored
  const detailed = DETAILED_LESSONS.find(d => d.day === dayNum);
  if (detailed) {
    _cache[dayNum] = detailed;
    return detailed;
  }

  // Days 6–45: procedurally generated
  const t = ADVANCED_TOPICS[dayNum - 6];
  if (!t) return null;

  // Fallback speech distractors built from *other* topics' romaji (not mangled)
  const otherRomajis = ADVANCED_TOPICS
    .filter((_, i) => i !== dayNum - 6)
    .map(x => x.romaji)
    .sort(() => Math.random() - 0.5)
    .slice(0, 2);

  let dailyExercises = [];
  const ROUNDS = 4;

  for (let round = 0; round < ROUNDS; round++) {
    dailyExercises.push({
      type: 'multiple_choice',
      question: `Situazione: ${t.scenario}. Cosa significa "${t.romaji}"?`,
      options: [t.eng, "Non capisco bene", "Dov'è il bagno?"],
      optionsHangul: [t.hangul, "몰라요", "화장실이 어디예요"],
      answer: 0,
      conceptTag: "Vocabolario Nuovo",
      tip: `Ricorda: ${t.clue}`
    });

    dailyExercises.push({
      type: 'listen',
      question: "[Shadowing] Ascolta l'audio 3 volte, chiudi gli occhi e ripeti ad alta voce imitando l'accento. Poi seleziona la risposta corretta:",
      audioHangul: t.hangul,
      options: [t.eng, "Vado in Palestra", "Quanto costa?"],
      answer: 0,
      conceptTag: "Ascolto",
      tip: "La ripetizione attiva (shadowing) è il segreto per sbloccare la scioltezza vocale!"
    });

    dailyExercises.push({
      type: 'speak',
      question: `Pronuncia: Dì '${t.eng}' in Coreano.`,
      expectedRomaji: [t.romaji.toLowerCase().replace(/[^a-z]/g, '')],
      expectedHangul: [t.hangul],
      conceptTag: "Pronuncia",
      feedback_incorrect: `Prova a dire '${t.romaji}' ad alta voce in modo chiaro.`,
      tip: "Non avere paura di sbagliare l'accento."
    });

    dailyExercises.push({
      type: 'conversation',
      context: `Sfida Fluidità: Ora che hai imparato "${t.eng}", pensa a come unirla con le frasi dei Giorni 1–5.`,
      question: `Nello scenario "${t.name}", qual è la frase chiave?`,
      options: [t.romaji, "Igeo juseyo", "Annyeonghaseyo"],
      optionsHangul: [t.hangul, "이거 주세요", "안녕하세요"],
      answer: 0,
      conceptTag: "Scenari Reali",
      tip: `Usa ${t.romaji} nel contesto giusto, sempre accompagnato da un sorriso.`
    });

    // Spaced repetition: pull a review exercise from a past day
    const reviewDayNum = Math.floor(Math.random() * Math.min(dayNum - 1, 5)) + 1;
    const pastDay = getDay(reviewDayNum);
    if (pastDay) {
      const reviewCandidates = pastDay.exercises.filter(ex =>
        ex.type === 'multiple_choice' || ex.type === 'listen'
      );
      if (reviewCandidates.length > 0) {
        const randomEx = reviewCandidates[Math.floor(Math.random() * reviewCandidates.length)];
        const reviewExercise = JSON.parse(JSON.stringify(randomEx));
        reviewExercise.question = '[Ripasso Spaziato] ' + reviewExercise.question;
        reviewExercise.conceptTag = "Ripasso Attivo";
        reviewExercise.tip = "I concetti vecchi tendono a svanire, rinfrescarli consolida la memoria a lungo termine!";
        dailyExercises.push(reviewExercise);
      }
    }
  }

  const day = {
    day: dayNum,
    title: `Giorno ${dayNum}: ${t.name}`,
    topic: "Conversazione Intermedia",
    theory: {
      intro: `Benvenuta al Giorno ${dayNum}! Oggi affrontiamo uno scenario essenziale: "${t.name}". Impareremo una frase nuova e faremo tanto ripasso attivo.`,
      concept: `Studia bene la frase chiave. Troverai domande ripetitive su di essa per fissarla nel cervello, più quiz a sorpresa dai Giorni passati!`,
      builderRule: `🔗 Prova a concatenare ${t.hangul} (${t.eng}) con una presentazione di te stessa come 저는 사라예요 o un ringraziamento come 감사합니다. Le frasi isolate non bastano, uniscile!`,
      examples: [{ hangul: t.hangul, romaji: t.romaji, eng: t.eng, context: "Frase Focus del Giorno ✨" }],
      culture: t.clue
    },
    exercises: dailyExercises,
    // Speech fallback distractors drawn from real vocabulary
    speechFallbackOptions: otherRomajis
  };

  _cache[dayNum] = day;
  return day;
};

/**
 * Returns all 45 days as a flat array (eager load — only for dashboard rendering).
 * This is lightweight since each day is just its metadata without exercises until needed.
 */
export const getAllDaysMeta = () =>
  Array.from({ length: 45 }, (_, i) => {
    const dayNum = i + 1;
    if (dayNum <= 5) {
      const d = DETAILED_LESSONS.find(x => x.day === dayNum);
      return { day: dayNum, title: d.title, topic: d.topic, exerciseCount: d.exercises.length };
    }
    const t = ADVANCED_TOPICS[dayNum - 6];
    return { day: dayNum, title: `Giorno ${dayNum}: ${t.name}`, topic: "Conversazione Intermedia", exerciseCount: 20 };
  });
