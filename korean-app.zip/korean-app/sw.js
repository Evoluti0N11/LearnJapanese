// ============================================================
// sw.js — Service Worker for offline support & asset caching
// ============================================================

const CACHE_NAME = 'korean-app-v3';
const SHELL_ASSETS = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/js/app.js',
  '/js/data.js',
  '/js/course.js',
  '/js/state.js',
  '/js/helpers.js',
  '/js/render.js',
  '/manifest.json',
];

// ─── INSTALL: pre-cache shell ─────────────────────────────────
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL_ASSETS))
  );
  self.skipWaiting();
});

// ─── ACTIVATE: remove old caches ─────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ─── FETCH: network-first for API, cache-first for assets ────
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Don't cache translation/external API calls
  if (url.hostname.includes('translate.googleapis') ||
      url.hostname.includes('googleapis.com') ||
      url.hostname.includes('gstatic.com') ||
      url.hostname.includes('fonts.googleapis') ||
      url.hostname.includes('cdn.tailwindcss')) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Map tiles: network-first, cache fallback
  if (url.hostname.includes('cartocdn') || url.hostname.includes('openstreetmap')) {
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // App shell: cache-first
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});
